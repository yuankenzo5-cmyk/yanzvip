# Login API (SQLite + Vercel)

## Cara Pakai
1. Clone project ini
2. Jalankan `npm install`
3. Jalankan `vercel dev` untuk testing lokal
4. Deploy ke Vercel untuk URL API publik

## Endpoint
POST /api/login
Body JSON:
```json
{
  "username": "admin",
  "password": "123456",
  "device_id": "ABC123"
}
```
